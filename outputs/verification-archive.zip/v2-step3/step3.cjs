const fs=require('fs');const rd=p=>fs.readFileSync(p,'utf8'),wr=(p,s)=>fs.writeFileSync(p,s);
const db=JSON.parse(rd('data/projects.json'));const [k,r,v]=db.projects;
for(const p of db.projects){p.group='main';p.heroImage=null;}
Object.assign(k,{titleEn:'KOICA Project Volunteer · Paraguay',period:'2025.11–2026.02',role:'홍보·캠페인팀',roleEn:'PR & Campaign Team',responsibilities:['온라인 홍보 콘텐츠 운영','오프라인 홍보물 제작','만성질환 인식개선 캠페인 2회','온·오프라인 사진전','성과공유회 PPT 및 영상','홍보 관련 기획서 및 결과보고서 작성','팀 업무 구조화','홍보 성과 기록'],resultsTitle:'Digital Communication Results',resultsTitleKo:'홍보·콘텐츠 운영 성과',results:[{value:'60',label:'Online Contents Published',detail:'44 Instagram · 11 Blog · 5 YouTube'},{value:'92,207',label:'Instagram Views'},{value:'2,599',label:'Instagram Profile Visits'},{value:'200',label:'Instagram Followers'}],resultNote:'약 2배 이상의 Follower Growth'});
Object.assign(r,{titleEn:'조사·데이터 분석',period:'2024.09–2024.12',researchTitle:'대학생의 전공 선택 동기가 진로 불안에 미치는 영향과 전공 만족도의 매개효과',process:['Research Design','Survey','Data Collection','SPSS Analysis','Interpretation','Conclusion'],contribution:'조사 설계, 데이터 수집, 분석과 해석 경험을 국제개발협력 분야의 성과·데이터 관련 업무를 이해하는 기초 역량으로 연결하고자 합니다.'});
r.methods.title='SPSS ANALYSIS EXPERIENCE';r.context+=' 아래 SPSS 분석 방법은 학업 전반의 활용 경험이며, 대표 연구에서 모두 사용했다는 의미는 아닙니다.';
const base={category:'',subtitle:'',period:'',location:'',role:'',summary:'',responsibilities:[],actions:[],results:[],skills:[],lessons:'',transferable:[],heroImage:null,images:[],group:'main'};
const w={...base,id:'welfare-practicum',category:'Social Welfare Practice',title:'갈산종합사회복지관 하계실습',titleEn:'Social Welfare Center Practicum',period:'2024.06–2024.07',role:'사회복지 현장실습',summary:'사례관리·서비스제공·지역조직화 순환 실습에서 주민 상담, 프로그램과 캠페인 기획·실행, 기록과 평가를 경험했습니다.',overview:'갈산종합사회복지관에서 하계실습에 참여하며 사례관리·서비스제공·지역조직화를 순환 실습했습니다.',responsibilities:['사례관리·서비스제공·지역조직화 순환 실습','주민 상담 및 상담일지 작성','프로그램 외부활동 기획','펫티켓 캠페인 기획 및 실행','자조모임 프로그램 기획','지역주민 대상 활동 운영','프로그램 계획서 및 결과보고서 작성','실습 목표 설정 및 평가'],skills:['Program Operations / 프로그램 운영','Documentation / 문서화','Field Communication / 현장 소통'],transferable:['Program Operations / 프로그램 운영','Documentation / 문서화','Field Communication / 현장 소통','Participant-centered Approach / 참여자 중심 접근'],evidence:[{competency:'program-field-operations',label:'복지관 프로그램·캠페인 기획·운영'}]};
const t={...base,id:'thesis',category:'Academic Recognition',title:'사회복지 우수 졸업논문',titleEn:'Excellent Graduation Thesis',period:'2025.02',summary:'2025.02 사회복지 우수 졸업논문 선정',overview:'2025.02 사회복지 우수 졸업논문 선정. 논문 제목과 연구 세부 정보는 확인 후 추가합니다.',thesis:{title:'[THESIS TITLE TBD]',question:'[RESEARCH QUESTION TBD]',method:'[METHOD TBD]',finding:'[KEY FINDING TBD]'}};
v.group='additional';v.titleEn='Venue Operations';v.title='공연장 현장 운영';
const add=(id,title,titleEn,period,responsibilities)=>({...base,id,title,titleEn,period,responsibilities,group:'additional'});
db.projects=[k,w,r,t,add('community-welfare','지역사회복지론 팀 프로젝트','Community Welfare Project','',['지역 내 쓰레기 배출 문제 관찰','문제 정의','해결방안 제안 및 직접 실행']),add('medical-social-welfare','의료사회사업연구학회','Medical Social Welfare Study Group','2020.07–2023',['의료복지 이슈 스터디 및 토의','가상 의료복지 사례에 사회복지실천 모델 적용','학과 학술제 참여 및 수상']),add('student-council','학생회 연대사업국','Student Council','2021.04–2021.12',['학과 모금 및 기부 활동','코로나19 시기 비대면 봉사활동 운영','학과 구성원 간 연대를 위한 비대면 프로그램 운영']),v];
wr('data/projects.json',JSON.stringify(db,null,2)+'\n');for(const p of db.projects){fs.mkdirSync('assets/images/projects/'+p.id,{recursive:true});wr('assets/images/projects/'+p.id+'/.gitkeep','');}
let h=rd('index.html').replace('<div id="projects-list" class="project-grid" role="region" aria-label="프로젝트 목록"></div>','<div id="projects-list" class="project-grid" role="region" aria-label="주요 프로젝트 목록"></div>\n            <div id="additional-experience" class="additional-experience" hidden>\n              <h3><span lang="en">ADDITIONAL EXPERIENCE</span><span class="title-ko">추가 경험</span></h3>\n              <div id="additional-list" class="additional-list"></div>\n            </div>');wr('index.html',h);
let js=rd('js/projects.js').replace('renderProjects(data.projects, container);','renderProjects(data.projects.filter(p => p.group !== "additional"), container);\n    renderAdditionalExperience(data.projects.filter(p => p.group === "additional"));');
js=js.replace('  title.id = titleId;','  title.id = titleId;\n  if (project.titleEn) title.append(projectText("span", "term-en", project.titleEn));');
js=js.replace('  article.append(category, title, role, summary, skillsLabel, skills);','  const hero = createHeroImage(project.heroImage);\n  if (hero) article.append(hero);\n  article.append(category, title);\n  if (project.period) article.append(projectText("p", "project-period", project.period));\n  if (project.role) {\n    if (project.roleEn) role.append(projectText("span", "term-en", project.roleEn));\n    article.append(role);\n  }\n  article.append(summary);\n  if (skills.childElementCount) article.append(skillsLabel, skills);');
js=js.replace('article.append(projectText("p", "card-result-scope", project.resultScope), createMetrics(project.results));','article.append(createResultHeading(project), projectText("p", "card-result-scope", project.resultScope), createMetrics(project.results));\n    if (project.resultNote) article.append(projectText("p", "result-note", project.resultNote));');
js=js.replace('  title.tabIndex = -1;','  title.tabIndex = -1;\n  if (project.titleEn) title.append(projectText("span", "term-en", project.titleEn));');
js=js.replace('  content.replaceChildren(header,','  const hero = createHeroImage(project.heroImage);\n  if (hero) header.append(hero);\n  content.replaceChildren(header,');
js=js.replace('gallery: "활동 이미지"','gallery: "활동 이미지", process: "연구 과정", thesis: "논문 정보 확인 예정", research: "대표 연구"');
js=js.replace('  const role = addSection("role", "MY ROLE");\n  role.append(projectText("p", "", project.role));','  if (project.role) {\n    const role = addSection("role", "MY ROLE");\n    role.append(projectText("p", "", project.role));\n    if (project.roleEn) role.append(projectText("p", "term-en", project.roleEn));\n  }\n  if (project.researchTitle) addSection("research", "FEATURED RESEARCH").append(projectText("p", "", project.researchTitle));\n  if (project.process?.length) addSection("process", "PROCESS").append(projectList(project.process, "research-process"));\n  if (project.thesis) addSection("thesis", "THESIS DETAILS").append(projectList(Object.values(project.thesis)));');
js=js.replace('    if (project.resultScope) result.append','    if (project.resultsTitle) result.append(createResultHeading(project));\n    if (project.resultNote) result.append(projectText("p", "result-note", project.resultNote));\n    if (project.resultScope) result.append');
js=js.replace('    metrics.append(item);','    if (metric.detail) item.append(projectText("dd", "metric-detail", metric.detail));\n    metrics.append(item);');
// Share URL/alt validation between hero images and existing galleries.
const start=js.indexOf('  const entries = (Array.isArray(images)');const end=js.indexOf('  if (!entries.length)',start);
js=js.slice(0,start)+'  const entries = (Array.isArray(images) ? images : []).filter(validProjectImage).slice(0, 5);\n'+js.slice(end);
js+=`\nfunction validProjectImage(item) {
  if (!item || typeof item.src !== "string" || typeof item.alt !== "string" || !item.alt.trim()) return false;
  try { const url = new URL(item.src, document.baseURI); return ["http:", "https:"].includes(url.protocol) && url.origin === location.origin; } catch { return false; }
}
function createHeroImage(item) {
  if (!validProjectImage(item)) return null;
  const figure = document.createElement("figure"); figure.className = "project-hero-image";
  const img = document.createElement("img"); img.src = item.src; img.alt = item.alt; img.loading = "lazy"; img.decoding = "async";
  img.addEventListener("error", () => figure.remove(), { once: true }); figure.append(img);
  if (item.caption) figure.append(projectText("figcaption", "", item.caption));
  return figure;
}
function createResultHeading(project) {
  const heading = projectText("p", "digital-results-heading", project.resultsTitle || "Results");
  if (project.resultsTitleKo) heading.append(projectText("span", "title-ko", project.resultsTitleKo));
  return heading;
}
function renderAdditionalExperience(projects) {
  const container = document.getElementById("additional-list");
  const region = document.getElementById("additional-experience");
  if (!container || !region) return;
  container.replaceChildren();
  projects.forEach(project => {
    const article = document.createElement("article"); article.className = "additional-item"; article.id = "project-" + project.id;
    const title = projectText("h4", "", project.title);
    if (project.titleEn) title.append(projectText("span", "term-en", project.titleEn));
    article.append(title);
    if (project.period) article.append(projectText("p", "project-period", project.period));
    const hero = createHeroImage(project.heroImage); if (hero) article.append(hero);
    if (project.summary) article.append(projectText("p", "", project.summary));
    if (project.responsibilities?.length) article.append(projectList(project.responsibilities));
    const gallery = createProjectGallery(project.images); if (gallery) article.append(gallery);
    container.append(article);
  });
  region.hidden = !container.childElementCount;
}
`;wr('js/projects.js',js);
let css=rd('css/style.css');css+='\n.additional-experience { margin-top: 48px; padding-top: 28px; border-top: 1px solid var(--border); }\n.additional-list { display: grid; gap: 24px; margin-top: 24px; }\n.additional-item { min-width: 0; padding-top: 16px; border-top: 1px solid var(--border); font-size: var(--text-sm); }\n.additional-item > p, .additional-item .case-gallery { margin-top: 12px; }\n.project-period, .metric-detail { color: var(--muted-text); font-size: var(--text-xs); margin-top: 8px; }\n.digital-results-heading { margin-top: 20px; font-weight: 650; color: var(--accent); }\n.result-note { margin-top: 12px; font-size: var(--text-sm); }\n.project-hero-image { margin: 0 0 20px; }\n.project-hero-image img { width: 100%; aspect-ratio: 3 / 2; object-fit: cover; object-position: center; border-radius: var(--border-radius); }\n.project-hero-image figcaption { margin-top: 6px; color: var(--muted-text); font-size: var(--text-xs); }\n.modal-project-header .project-hero-image { margin-top: 20px; }\n.modal-project-header .project-hero-image img { max-height: 65vh; aspect-ratio: auto; object-fit: contain; }\n.research-process { display: flex; flex-wrap: wrap; gap: 12px 28px; padding-left: 20px; }\n';wr('css/style.css',css);
wr('css/responsive.css',rd('css/responsive.css')+'\n@media (min-width: 640px) { .additional-list { grid-template-columns: repeat(2, minmax(0, 1fr)); } }\n');

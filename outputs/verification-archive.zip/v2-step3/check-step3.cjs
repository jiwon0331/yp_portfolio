const fs=require('fs'),path=require('path'),http=require('http'),assert=require('assert');
const {chromium}=require(path.resolve(path.dirname(process.execPath),'../node_modules/playwright'));
(async()=>{
const root=path.resolve('outputs/site');
const server=http.createServer((q,s)=>{const f=path.join(root,decodeURIComponent(q.url.split('?')[0]==='/'?'/index.html':q.url.split('?')[0])); if(!f.startsWith(root+path.sep)){s.writeHead(403).end();return;} fs.readFile(f,(e,b)=>{s.writeHead(e?404:200,{'Content-Type':({'.html':'text/html','.css':'text/css','.js':'text/javascript','.json':'application/json','.svg':'image/svg+xml','.png':'image/png'})[path.extname(f)]||'application/octet-stream'});s.end(e?'missing':b);});});
await new Promise(r=>server.listen(0,'127.0.0.1',r)); let browser;
try{ browser=await chromium.launch({executablePath:'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',headless:true});
for(const width of [375,430,768,1024,1440]) {
 const page=await browser.newPage({viewport:{width,height:900},reducedMotion:'reduce'}); const errors=[];page.on('pageerror',e=>errors.push(e.message));
 await page.goto('http://127.0.0.1:'+server.address().port);await page.locator('.project-case-button').first().waitFor();
 assert.equal(await page.locator('.project-card').count(),4);
 assert.equal(await page.locator('.additional-item').count(),4);
 assert.equal(await page.locator('.project-hero-image, .case-gallery').count(),0);
 assert((await page.locator('#project-koica-paraguay').innerText()).includes('92,207'));
 assert((await page.locator('#project-koica-paraguay').innerText()).includes('44 Instagram · 11 Blog · 5 YouTube'));
 await page.locator('#project-thesis .project-case-button').click();
 assert((await page.locator('dialog').innerText()).includes('[KEY FINDING TBD]'));
 await page.keyboard.press('Escape');
 await page.locator('#project-welfare-practicum .project-case-button').click();
 assert((await page.locator('dialog').innerText()).includes('펫티켓'));
 await page.keyboard.press('Escape');
 await page.waitForTimeout(100);
 await page.evaluate(()=>{const p={id:'fixture',title:'사진 검수',overview:'검수',heroImage:{src:'assets/images/og-image.png',alt:'대표 이미지 검수'},images:[{src:'assets/images/og-image.png',alt:'갤러리 검수',caption:'검수'}]};openProjectDialog(p,document.querySelector('.project-case-button'));});
 assert.equal(await page.locator('dialog img').count(),2);
 await page.keyboard.press('Escape');
 assert.deepEqual(await page.locator('[data-nav-link]').allTextContents(),['Experience','Projects','Skills','Learning','About','Contact']);
 assert.deepEqual(await page.locator('.section-heading > .eyebrow').allTextContents(),['01','02','03','04','05','06']);
 assert.equal(await page.locator('[data-resume-placeholder],.journey-number').count(),0);
 assert(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));
 for(const id of ['learning','contact']){if(width<960)await page.locator('.menu-toggle').click();await page.locator(`[data-nav-link][href="#${id}"]`).click();await page.waitForTimeout(100);assert.equal(await page.locator(`[data-nav-link][href="#${id}"]`).getAttribute('aria-current'),'location');}
 await page.locator('.project-case-button').first().click();assert(await page.locator('dialog').evaluate(d=>d.open));assert(await page.locator('dialog .title-ko').count()>3);await page.keyboard.press('Escape');assert(!(await page.locator('dialog').evaluate(d=>d.open)));
 assert.deepEqual(errors,[]);await page.goto('http://127.0.0.1:'+server.address().port);await page.locator('.project-card').first().waitFor();
 if([375,1440].includes(width))await page.locator('#featured-projects').screenshot({path:`work/v2-step3-${width}.png`});
 console.log(width+': layout, navigation, numbering, modal passed');await page.close();
}
}finally{if(browser)await browser.close();server.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});

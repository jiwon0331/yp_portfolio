const fs=require('fs'),path=require('path'),http=require('http'),assert=require('assert');const {chromium}=require(path.resolve(path.dirname(process.execPath),'../node_modules/playwright'));
const db=JSON.parse(fs.readFileSync('data/projects.json','utf8'));
(async()=>{const root=path.resolve('outputs/site');const server=http.createServer((q,s)=>{let url=decodeURIComponent(q.url.split('?')[0]);if(!url.startsWith('/portfolio/')){s.writeHead(404).end();return;}let f=path.resolve(root,url.slice(11)||'index.html');if(!f.startsWith(root+path.sep)){s.writeHead(403).end();return;}fs.readFile(f,(e,b)=>{s.writeHead(e?404:200,{'Content-Type':({'.html':'text/html','.css':'text/css','.js':'text/javascript','.json':'application/json','.png':'image/png','.svg':'image/svg+xml'})[path.extname(f)]||'application/octet-stream'});s.end(e?'missing':b);});});await new Promise(r=>server.listen(0,'127.0.0.1',r));let browser;const results=[];
try{browser=await chromium.launch({executablePath:'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',headless:true});
for(const width of [375,430,768,1024,1440]){
 const p=await browser.newPage({viewport:{width,height:900},reducedMotion:'reduce'});const errors=[];p.on('pageerror',e=>errors.push(e.message));p.on('response',r=>{if(r.status()>=400)errors.push(r.url());});
 await p.goto('http://127.0.0.1:'+server.address().port+'/portfolio/');await p.locator('.project-card').first().waitFor();
 assert.deepEqual(await p.locator('.project-card').evaluateAll(es=>es.map(e=>e.dataset.projectId)),['koica-paraguay','welfare-practicum','research-data-analysis','thesis']);
 assert.equal(await p.locator('.additional-item').count(),4);assert.equal(await p.locator('.evidence-list li').count(),15);assert.equal(await p.locator('.journey-step').count(),4);
 assert.deepEqual(await p.locator('.section-heading > .eyebrow').allTextContents(),['01','02','03','04','05','06']);
 assert.equal(await p.locator('.project-hero-image,.case-gallery').count(),0);
 assert(await p.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));
 const structural=await p.evaluate(()=>{const ids=[...document.querySelectorAll('[id]')].map(e=>e.id);const hs=[...document.querySelectorAll('main h1,main h2,main h3,main h4')].map(e=>+e.tagName[1]);return {unique:ids.length===new Set(ids).size,jumps:hs.filter((n,i)=>i&&n>hs[i-1]+1),h1:document.querySelectorAll('h1').length,badLinks:[...document.querySelectorAll('a[href^="#"]')].filter(a=>!document.getElementById(a.hash.slice(1))).length};});assert(structural.unique);assert.equal(structural.h1,1);assert.deepEqual(structural.jumps,[]);assert.equal(structural.badLinks,0);
 await p.keyboard.press('Tab');assert.equal(await p.evaluate(()=>document.activeElement.className),'skip-link');await p.keyboard.press('Enter');assert.equal(await p.evaluate(()=>document.activeElement.id),'main-content');
 for(const id of ['journey','featured-projects','skills','learning','about','contact']){if(width<960)await p.locator('.menu-toggle').click();await p.locator(`[data-nav-link][href="#${id}"]`).click();await p.waitForTimeout(80);assert.equal(await p.locator(`[data-nav-link][href="#${id}"]`).getAttribute('aria-current'),'location');}
 assert.equal(await p.locator('#contact a').first().getAttribute('href'),'tel:01077621796');assert.equal(await p.locator('#contact a').last().getAttribute('href'),'mailto:qwerty010331@gmail.com');
 for(const button of await p.locator('.project-case-button,.evidence-button').all()){
 await button.click();assert.equal(await p.evaluate(()=>document.activeElement.id),'project-dialog-title');assert.equal(await p.evaluate(()=>document.body.style.position),'fixed');await p.keyboard.press('Tab');assert.equal(await p.evaluate(()=>document.activeElement.className),'modal-close');await p.keyboard.press('Shift+Tab');assert.equal(await p.evaluate(()=>document.activeElement.className),'modal-close');
 const bounds=await p.locator('dialog').boundingBox();assert(bounds.x>=0&&bounds.y>=0&&bounds.x+bounds.width<=width+1&&bounds.y+bounds.height<=901);
 assert(await p.locator('.modal-content').evaluate(e=>e.scrollWidth<=e.clientWidth));assert.equal(await p.locator('dialog .case-gallery').count(),0);await p.keyboard.press('Escape');await p.waitForTimeout(30);assert(!(await p.locator('dialog').evaluate(d=>d.open)));assert(await button.evaluate(e=>e===document.activeElement));}
 await p.locator('.project-case-button').first().click();await p.locator('.modal-close').click();await p.waitForTimeout(30);await p.locator('.project-case-button').first().click();await p.mouse.click(2,2);await p.waitForTimeout(30);assert(!(await p.locator('dialog').evaluate(d=>d.open)));
 const fixture={...db.projects[0],heroImage:{src:'assets/images/og-image.png',alt:'대표 이미지 검수'},images:Array.from({length:5},(_,i)=>({src:'assets/images/og-image.png',alt:'사진 '+i,caption:'검수용 이미지'}))};
 await p.evaluate(x=>openProjectDialog(x,document.querySelector('.project-case-button')),fixture);assert.equal(await p.locator('dialog img').count(),6);assert.equal(await p.locator('dialog img:not([alt]),dialog img[alt=""]').count(),0);assert(await p.locator('.modal-content').evaluate(e=>e.scrollWidth<=e.clientWidth));await p.keyboard.press('Escape');await p.waitForTimeout(30);
 assert.deepEqual(errors,[]);results.push({width,status:'passed'});console.log(width+': all regression checks passed');
 if([375,1440].includes(width)){await p.evaluate(()=>{document.querySelector('.site-header').style.position='static';window.scrollTo(0,0);});await p.screenshot({path:`work/qa-${width}.png`,fullPage:true});}
 await p.close();
}
fs.writeFileSync('work/qa-results.json',JSON.stringify(results,null,2));
}finally{if(browser)await browser.close();server.close();}})().catch(e=>{console.error(e);process.exitCode=1;});

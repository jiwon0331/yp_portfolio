const path = require('node:path');
const { chromium } = require(path.resolve(path.dirname(process.execPath), '../node_modules/playwright'));
(async () => {
  const browser = await chromium.launch({ channel: 'msedge', headless: true });
  try {
    const page = await browser.newPage({ viewport: { width: 1200, height: 630 }, deviceScaleFactor: 1 });
    await page.setContent(`<!doctype html><html lang="ko"><meta charset="utf-8"><style>
      *{box-sizing:border-box}body{margin:0;background:#faf9f6;color:#202e2b;font-family:'Segoe UI','Malgun Gothic',sans-serif;width:1200px;height:630px;padding:62px 76px;border-top:12px solid #285b49}
      .top{color:#285b49;font-size:20px;letter-spacing:2px}h1{font-size:64px;margin:46px 0 14px;font-weight:650}h2{font-size:34px;font-weight:500;margin:0;line-height:1.5}footer{border-top:1px solid #d9ded7;margin-top:54px;padding-top:24px;display:flex;justify-content:space-between;font-size:20px;color:#5b6661}
      </style><body><div class="top">INTERNATIONAL DEVELOPMENT PORTFOLIO</div><h1>문지원</h1><h2>현장의 경험을,<br>국제개발협력 사업 운영의 이해로.</h2><footer><span>현장 운영 · 커뮤니케이션 · 조사·분석</span><span>YP PORTFOLIO</span></footer></body></html>`);
    await page.evaluate(() => new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve))));
    await page.screenshot({ path: 'assets/images/og-image.png', animations: 'disabled', timeout: 15000 });
  } finally { await browser.close(); }
})();

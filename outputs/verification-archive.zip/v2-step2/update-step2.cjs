const fs=require('fs');const read=p=>fs.readFileSync(p,'utf8');const write=(p,v)=>fs.writeFileSync(p,v);
let h=read('index.html');
const items=[
['program-field-operations','operations','프로그램·현장 운영','Program &amp; Field Operations','프로그램, 캠페인 및 현장 활동을 직접 기획·지원하고 실행한 경험',[
'종합사회복지관 실습에서 프로그램 및 지역주민 대상 캠페인 기획·운영','KOICA 프로젝트 봉사단에서 만성질환 인식개선 캠페인 2회 운영','온·오프라인 사진전 및 성과공유회 운영 지원']],
['communication-coordination','communication','커뮤니케이션·협업','Communication &amp; Coordination','다양한 참여자 및 관계자와 소통하며 실제 활동을 조율한 경험',[
'KOICA 프로젝트 봉사단 홍보·캠페인팀 협업','파라과이 현지 직원과 스페인어 표현 검수 및 캠페인 협업','Paraguay TV, ABC Color 등 현지 언론 인터뷰 참여','학생회 활동을 통한 구성원 참여 프로그램 운영']],
['documentation-organization','documentation','문서화·업무 구조화','Documentation &amp; Organization','활동 과정을 기록하고 일정·업무·결과를 구조화한 경험',[
'복지관 실습에서 상담일지, 프로그램 계획서 및 결과보고서 작성','KOICA 프로젝트 봉사단에서 캠페인 기획서·결과보고서, 홍보 기획서·결과보고서, 성과공유회 기획서 작성','팀 업무가 집중되는 기간에 마감일·우선순위·담당자를 정리해 업무 흐름 공유','온라인 홍보 성과 수치를 지속적으로 기록하고 결과보고서 업데이트']],
['research-data','research','조사·데이터','Research &amp; Data','사회복지·심리 연구를 통해 조사 설계부터 분석과 해석까지 경험',[
'대학생 전공 선택 동기와 진로 불안을 주제로 실제 설문 연구 진행','연구설계 → 데이터 수집 → SPSS 분석 → 결과 해석 경험','Regression, Mediation Analysis 등 활용','사회복지 우수 졸업논문 선정']]];
const cards=items.map(([key,id,ko,en,desc,evidence])=>`            <article class="competency" data-competency="${key}" aria-labelledby="${id}-title">
              <h3 id="${id}-title">${ko}<span class="term-en" lang="en">${en}</span></h3>
              <p class="competency-description">${desc}</p>
              <div class="competency-evidence">
                <p class="evidence-label"><span lang="en">Evidence</span> / 경험 근거</p>
                <ul class="evidence-list">${evidence.map(s=>`\n                  <li>${s}</li>`).join('')}
                </ul>
              </div>
              <div class="competency-related" data-evidence-for="${key}"></div>
            </article>`).join('\n');
h=h.replace(/(<div class="competency-grid">)[\s\S]*?(\n          <\/div>\n        <\/div>\n      <\/section>)/,'$1\n'+cards+'$2');
const journey=`          <ol class="journey-timeline" role="list">
            <li class="journey-step">
              <h3><span lang="en">Social Welfare &amp; Psychology</span><span class="title-ko">사회복지 · 심리</span></h3>
              <p>사회복지와 심리학을 공부하며 사람과 사회 문제를 이해하는 것에서 출발했습니다.</p>
              <div class="journey-experiences">
                <div class="journey-experience">
                  <h4>의료사회사업연구학회<span class="term-en" lang="en">Medical Social Welfare Study Group</span></h4>
                  <p class="journey-period"><time datetime="2020-07">2020.07</time>–<time datetime="2023">2023</time></p>
                  <ul><li>의료복지 이슈 스터디 및 토의</li><li>가상 의료복지 사례에 사회복지실천 모델 적용</li><li>학과 학술제 참여 및 수상</li></ul>
                </div>
                <div class="journey-experience">
                  <h4>학과 학생회 연대사업국 국장<span class="term-en" lang="en">Student Council</span></h4>
                  <p class="journey-period"><time datetime="2021-04">2021.04</time>–<time datetime="2021-12">2021.12</time></p>
                  <ul><li>학과 모금 및 기부 활동</li><li>코로나19 시기 비대면 봉사활동 운영</li><li>학과 구성원 간 연대를 위한 비대면 프로그램 운영</li></ul>
                </div>
              </div>
            </li>
            <li class="journey-step">
              <h3><span lang="en">Sweden Exchange</span><span class="title-ko">스웨덴 교환학생</span></h3>
              <p class="journey-period"><time datetime="2023-01">2023.01</time>–<time datetime="2023-06">2023.06</time></p>
              <p class="journey-course" lang="en">Social Work and Social Policy for a Sustainable Future</p>
              <p>해당 강의와 세미나를 통해 사회복지·사회정책을 지속가능성과 국제적 관점에서 바라보는 경험을 했습니다.</p>
              <p class="journey-keyword" lang="en">SDGs</p>
            </li>
            <li class="journey-step">
              <h3>KOICA 프로젝트 봉사단 · Paraguay<span class="term-en" lang="en">KOICA Project Volunteer · Paraguay</span></h3>
              <p class="journey-period"><time datetime="2025-11">2025.11</time>–<time datetime="2026-02">2026.02</time></p>
              <p>파라과이 노인복지센터에서 프로그램, 캠페인, 홍보 활동을 수행하며 국제개발협력 사업이 현장에서 실행되는 과정을 경험했습니다.</p>
            </li>
            <li class="journey-step">
              <h3><span lang="en">From Field to Operations</span><span class="title-ko">현장에서 사업 운영으로</span></h3>
              <p>현장 활동을 통해 일정, 기록, 협업, 성과 정리의 중요성을 체감했고, 사업수행기관 내부에서는 이러한 사업이 어떻게 기획되고 운영되는지에 관심을 갖게 되었습니다.</p>
              <p>지금까지 쌓은 현장 운영, 커뮤니케이션, 조사·분석 역량으로 실무에 기여하면서 국제개발협력 사업의 행정과 운영 구조를 배우고 싶습니다.</p>
            </li>
          </ol>`;
h=h.replace(/          <ol class="journey-timeline"[\s\S]*?          <\/ol>/,journey);write('index.html',h);
let css=read('css/style.css').replace('.competency-evidence { margin-top: auto;', '.competency-evidence { margin-top: 0;');
css+='\n/* Expanded evidence remains readable without opening a case study. */\n.evidence-list { display: grid; gap: 8px; margin-top: 10px; padding-left: 18px; font-size: var(--text-sm); }\n.evidence-list li::marker { color: var(--accent); }\n.competency-related:not(:empty) { margin-top: auto; padding-top: 20px; }\n.journey-experiences { display: grid; gap: 20px; margin-top: 20px; }\n.journey-experience { border-top: 1px solid var(--border); padding-top: 12px; }\n.journey-experience h4 { font-size: var(--text-sm); line-height: 1.5; }\n.journey-experience ul { margin-top: 8px; padding-left: 16px; color: var(--muted-text); font-size: var(--text-xs); }\n.journey-step .journey-period { margin-top: 8px; color: var(--accent); font-size: var(--text-xs); font-variant-numeric: tabular-nums; }\n.journey-step .journey-course { color: var(--text); font-weight: 650; }\n.journey-step .journey-keyword { color: var(--accent); font-size: var(--text-xs); }\n';write('css/style.css',css);
let r=read('css/responsive.css').replace('.profile-list, .competency-grid { grid-template-columns: repeat(4, minmax(0, 1fr)); }','.profile-list { grid-template-columns: repeat(4, minmax(0, 1fr)); }').replace('grid-template-columns: repeat(5, minmax(0, 1fr))','grid-template-columns: repeat(4, minmax(0, 1fr))');write('css/responsive.css',r);
let js=read('js/projects.js').replace('"Evidence / 경험 근거"','"Related Case / 관련 사례"');write('js/projects.js',js);
let doc=read('README.md').replace('역량·프로젝트 확장, 실제 연락처 및 이미지 추가는 후속 단계에서 제공되는 콘텐츠를 기준으로 진행합니다.','STEP 2에서는 4개 역량의 구체적 Evidence와 4단계 Experience Journey(학회·학생회, 교환학생 강의, 봉사단 기간 포함)를 반영했습니다. 설문 연구 주제와 우수 졸업논문 선정 사실은 별개로 표기하며 졸업논문 제목·상세 내용은 확정하지 않았습니다. 프로젝트 확장, 실제 연락처 및 이미지 추가는 후속 단계에서 제공되는 콘텐츠를 기준으로 진행합니다.');write('README.md',doc);

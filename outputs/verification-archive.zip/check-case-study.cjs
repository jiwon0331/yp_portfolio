const fs = require('node:fs');
const path = require('node:path');
const http = require('node:http');
const assert = require('node:assert/strict');
const { chromium } = require(path.resolve(path.dirname(process.execPath), '../node_modules/playwright'));

(async () => {
  const root = process.cwd();
  const types = { '.html': 'text/html; charset=utf-8', '.css': 'text/css', '.js': 'text/javascript', '.json': 'application/json' };
  const server = http.createServer((req, res) => {
    const file = path.resolve(root, '.' + (req.url === '/' ? '/index.html' : req.url.split('?')[0]));
    if (!file.startsWith(root + path.sep)) { res.writeHead(403).end(); return; }
    fs.readFile(file, (err, data) => {
      if (err) { res.writeHead(404).end(); return; }
      res.writeHead(200, { 'Content-Type': types[path.extname(file)] || 'application/octet-stream' });
      res.end(data);
    });
  });
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  let browser;
  try {
    browser = await chromium.launch({ channel: 'msedge', headless: true });
    const page = await browser.newPage();
    const errors = [];
    page.on('pageerror', error => errors.push(error.message));
    for (const width of [1440, 390, 320]) {
      await page.setViewportSize({ width, height: 900 });
      await page.goto(`http://127.0.0.1:${server.address().port}/`);
      await page.waitForSelector('.project-card');
      assert.equal(await page.locator('.project-card').count(), 3);
      const card = page.locator('#project-koica-paraguay');
      const button = card.locator('button');
      await button.click();
      assert.equal(await button.getAttribute('aria-expanded'), 'true');
      assert.equal(await card.locator('.case-section').count(), 7);
      assert.equal(await card.locator('.case-metrics > div').count(), 4);
      assert.match(await card.locator('.case-result-scope').innerText(), /홍보·콘텐츠 운영 성과/);
      await card.locator('.case-section').first().locator('p').click();
      assert.equal(await button.getAttribute('aria-expanded'), 'true');
      assert.ok(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth), `Overflow at ${width}`);
      if (width === 1440 || width === 390) {
        await card.screenshot({ path: `work/koica-${width}.png` });
      }
      await button.focus();
      await page.keyboard.press('Enter');
      assert.equal(await button.getAttribute('aria-expanded'), 'false');
      for (const [id, sectionCount, responsibilities] of [['research-data-analysis', 5, 5], ['field-service-operations', 4, 6]]) {
        const item = page.locator(`#project-${id}`);
        const toggle = item.locator('button');
        await toggle.click();
        assert.equal(await item.locator('.case-section').count(), sectionCount);
        assert.equal(await item.locator(`[aria-labelledby="project-${id}-role"] li`).count(), responsibilities);
        assert.equal(await item.locator('.case-metrics').count(), 0);
        assert.ok(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth));
        if (width === 1440 || width === 390) await item.screenshot({ path: `work/${id}-${width}.png` });
        await toggle.focus();
        await page.keyboard.press('Space');
        assert.equal(await toggle.getAttribute('aria-expanded'), 'false');
      }
      assert.equal(await page.locator('#project-research-data-analysis [aria-labelledby="project-research-data-analysis-methods"] li').count(), 6);
      assert.equal(await page.locator('#skills .skill-group').count(), 5);
      assert.equal(await page.locator('#skills li').count(), 17);
      if (width === 1440 || width === 390) await page.locator('#skills').screenshot({ path: `work/skills-${width}.png` });
      console.log(`PASS ${width}px: cards, sections, metrics, content click, keyboard close, no horizontal overflow`);
    }
    assert.deepEqual(errors, []);
    console.log('PASS: no browser script errors');
  } finally {
    if (browser) await browser.close();
    server.close();
  }
})().catch(error => { console.error(error); process.exitCode = 1; });

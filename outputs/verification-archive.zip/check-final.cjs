const fs = require('node:fs');
const path = require('node:path');
const http = require('node:http');
const assert = require('node:assert/strict');
const { chromium } = require(path.resolve(path.dirname(process.execPath), '../node_modules/playwright'));

(async () => {
  const root = path.join(process.cwd(), 'outputs/site');
  const types = { '.html': 'text/html; charset=utf-8', '.css': 'text/css', '.js': 'text/javascript', '.json': 'application/json' };
  const server = http.createServer((req, res) => {
    const requested = req.url.replace(/^\/portfolio\//, '/');
    const file = path.resolve(root, '.' + (requested === '/' ? '/index.html' : requested.split('?')[0]));
    if (!file.startsWith(root + path.sep)) { res.writeHead(403).end(); return; }
    fs.readFile(file, (err, data) => {
      if (err) { res.writeHead(404).end(); return; }
      res.writeHead(200, { 'Content-Type': types[path.extname(file)] || 'application/octet-stream' });
      res.end(data);
    });
  });
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  let browser;
  try {
    browser = await chromium.launch({ channel: 'msedge', headless: true });
    const page = await browser.newPage();
    const errors = [];
    page.on('pageerror', error => errors.push(error.message));
    page.on('console', message => { if(message.type() === 'error') errors.push(message.text()); });
    page.on('response', response => { if(response.status() >= 400) errors.push(`${response.status()} ${response.url()}`); });
    for (const width of [375, 430, 768, 1024, 1440]) {
      await page.setViewportSize({ width, height: 900 });
      await page.goto(`http://127.0.0.1:${server.address().port}/portfolio/`);
      await page.waitForSelector('.project-card');
      assert.equal(await page.title(), '문지원 | International Development Portfolio');
      assert.equal(await page.locator('.evidence-button').count(), 4);
      const evidence = page.locator('.evidence-button').first();
      await evidence.click();
      assert.ok(await page.locator('#project-dialog').isVisible());
      await page.keyboard.press('Escape');
      await page.waitForFunction(() => !document.querySelector('#project-dialog').open && document.body.style.position !== 'fixed');
      assert.ok(await evidence.evaluate(el => document.activeElement === el));
      await page.evaluate(() => window.scrollTo(0,0));
      for (const [, ref] of (await page.content()).matchAll(/(?:href|src)="(\.\/[^\"]+)"/g)) {
        const response = await page.request.get(new URL(ref, page.url()).href);
        assert.ok(response.ok(), ref);
      }
      assert.ok(await page.evaluate(() => [...document.querySelectorAll('a[href^="#"]')].every(a => a.hash === '' || !!document.getElementById(a.hash.slice(1)))));
      await page.screenshot({ path: `work/responsive-${width}.png`, fullPage: true });
      const toggle = page.locator('.menu-toggle');
      if (width < 960) {
        assert.ok(await toggle.isVisible());
        assert.ok(!(await page.locator('#primary-navigation').isVisible()));
        await toggle.click();
        assert.ok(await page.locator('#primary-navigation').isVisible());
        await page.keyboard.press('Escape');
        assert.ok(await toggle.evaluate(el => document.activeElement === el));
        await toggle.click();
      } else assert.ok(!(await toggle.isVisible()));
      await page.locator('[data-nav-link][href="#skills"]').click();
      await page.waitForFunction(() => Math.abs(document.getElementById('skills').getBoundingClientRect().top - parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--anchor-offset'))) < 3);
      assert.equal(await page.locator('[data-nav-link][href="#skills"]').getAttribute('aria-current'), 'location');
      if (width < 960) assert.ok(!(await page.locator('#primary-navigation').isVisible()));
      await page.evaluate(() => document.getElementById('journey').scrollIntoView({behavior:'instant'}));
      await page.waitForFunction(() => document.querySelector('[href="#journey"][data-nav-link]').getAttribute('aria-current') === 'location');
      const overflow = await page.evaluate(() => document.documentElement.scrollWidth > innerWidth);
      assert.equal(overflow, false);
      assert.ok(await page.locator('h1').evaluate(el => {
        const text = el.textContent;
        el.textContent = 'InternationalCollaboration'.repeat(15);
        const ok = document.documentElement.scrollWidth <= innerWidth;
        el.textContent = text;
        return ok;
      }));
      if (width < 640) {
        assert.ok(await page.locator('#hero').evaluate(el => el.getBoundingClientRect().height < 580));
        assert.equal(await page.locator('.project-grid').evaluate(el => getComputedStyle(el).gridTemplateColumns.split(' ').length), 1);
        assert.equal(await page.locator('.competency-grid').evaluate(el => getComputedStyle(el).gridTemplateColumns.split(' ').length), 1);
      }
      if (width < 960) assert.equal(await page.locator('.journey-timeline').evaluate(el => getComputedStyle(el).display), 'block');
      for (const target of await page.locator('.hero-actions a, .project-case-button, .menu-toggle').all()) {
        if (await target.isVisible()) assert.ok(await target.evaluate(el => { const r = el.getBoundingClientRect(); return r.height >= 44 && r.width >= 44; }));
      }
      assert.equal(await page.locator('.project-card').count(), 3);
      const card = page.locator('#project-koica-paraguay');
      const button = card.locator('button');
      await button.click();
      const modal = page.locator('#project-dialog');
      assert.ok(await modal.isVisible());
      assert.equal(await page.evaluate(() => document.activeElement.id), 'project-dialog-title');
      assert.equal(await page.evaluate(() => getComputedStyle(document.body).position), 'fixed');
      assert.equal(await modal.locator('.case-metrics > div').count(), 4);
      assert.match(await modal.locator('.case-result-scope').innerText(), /홍보·콘텐츠 운영 성과/);
      assert.equal(await modal.locator('.case-gallery').count(), 0);
      await modal.locator('.modal-title').click();
      assert.ok(await modal.isVisible());
      for (const key of ['Tab', 'Tab', 'Shift+Tab']) {
        await page.keyboard.press(key);
        assert.ok(await modal.evaluate(el => el.contains(document.activeElement)));
      }
      const content = modal.locator('.modal-content');
      await content.evaluate(el => { el.scrollTop = el.scrollHeight; });
      assert.ok(await content.evaluate(el => el.scrollTop > 0));
      assert.ok(await content.evaluate(el => el.scrollWidth <= el.clientWidth));
      await content.evaluate(el => { el.scrollTop = 0; });
      assert.ok(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth), `Overflow at ${width}`);
      assert.ok(await modal.evaluate(el => { const r=el.getBoundingClientRect(); return r.left >= 0 && r.top >= 0 && r.right <= innerWidth && r.bottom <= innerHeight; }));
      const metrics = await modal.locator('.case-metrics > div').evaluateAll(els => els.map(el => {const r=el.getBoundingClientRect(); return {left:r.left,right:r.right,top:r.top,bottom:r.bottom};}));
      for(let i=0;i<metrics.length;i++) for(let j=i+1;j<metrics.length;j++) assert.ok(metrics[i].right <= metrics[j].left || metrics[j].right <= metrics[i].left || metrics[i].bottom <= metrics[j].top || metrics[j].bottom <= metrics[i].top);
      if (width === 1440 || width === 375) {
        await page.screenshot({ path: `work/modal-${width}.png` });
      }
      await page.keyboard.press('Escape');
      await page.waitForFunction(() => !document.querySelector('#project-dialog').open && document.body.style.position !== 'fixed');
      assert.ok(await button.evaluate(el => document.activeElement === el));
      for (const [id, responsibilities] of [['research-data-analysis', 5], ['field-service-operations', 6]]) {
        const item = page.locator(`#project-${id}`);
        const toggle = item.locator('button');
        await toggle.click();
        assert.equal(await modal.locator(`[aria-labelledby="project-${id}-action"] li`).count(), responsibilities);
        assert.equal(await modal.locator('.case-metrics').count(), 0);
        assert.ok(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth));
        if (id === 'research-data-analysis') await page.mouse.click(2, 2);
        else await modal.locator('.modal-close').click();
        await page.waitForFunction(() => !document.querySelector('#project-dialog').open && document.body.style.position !== 'fixed');
        assert.ok(await toggle.evaluate(el => document.activeElement === el));
      }
      assert.equal(await page.locator('#skills .skill-group').count(), 5);
      assert.equal(await page.locator('#skills li').count(), 17);
      if (width === 1440 || width === 390) await page.locator('#skills').screenshot({ path: `work/skills-${width}.png` });
      console.log(`PASS ${width}px: menu/scrollspy, anchors, touch sizes, long text, layouts, metrics, modal keyboard and bounds`);
    }
    await page.emulateMedia({ reducedMotion: 'reduce' });
    await page.goto(`http://127.0.0.1:${server.address().port}/`);
    await page.waitForSelector('.project-card');
    await page.evaluate(() => {
      window.scrollBehaviors = [];
      const original = Element.prototype.scrollIntoView;
      Element.prototype.scrollIntoView = function(options) { window.scrollBehaviors.push(options.behavior); return original.call(this, options); };
    });
    await page.locator('.hero-actions a').first().click();
    assert.deepEqual(await page.evaluate(() => window.scrollBehaviors), ['auto']);
    assert.equal(await page.locator('.project-card').first().evaluate(el => getComputedStyle(el).transitionDuration), '0s');
    console.log('PASS: prefers-reduced-motion uses instant anchor scrolling and disables transitions');
    const fixture = JSON.parse(fs.readFileSync('data/projects.json', 'utf8'));
    fixture.projects[0].images = Array.from({ length: 5 }, (_, i) => ({ src: `./assets/images/test-${i}.svg`, alt: `Test image ${i}`, caption: `Test caption ${i}` }));
    await page.route('**/data/projects.json', route => route.fulfill({ json: fixture }));
    await page.route('**/assets/images/test-*.svg', route => route.fulfill({ contentType: 'image/svg+xml', body: '<svg xmlns="http://www.w3.org/2000/svg" width="800" height="400"><rect width="800" height="400" fill="#d9ded7"/></svg>' }));
    await page.goto(`http://127.0.0.1:${server.address().port}/`);
    await page.locator('#project-koica-paraguay button').click();
    const gallery = page.locator('#project-dialog .case-gallery');
    assert.equal(await gallery.locator('img').count(), 5);
    assert.equal(await gallery.locator('.gallery-image-primary').count(), 1);
    assert.deepEqual(await gallery.locator('img').evaluateAll(imgs => imgs.map(img => img.alt)), fixture.projects[0].images.map(img => img.alt));
    await gallery.scrollIntoViewIfNeeded();
    assert.ok(await page.locator('.modal-content').evaluate(el => el.scrollWidth <= el.clientWidth));
    console.log('PASS: gallery primary + four supporting images, alt text, mobile layout with in-memory fixtures only');
    assert.deepEqual(errors, []);
    console.log('PASS: no browser script errors');
  } finally {
    if (browser) await browser.close();
    server.close();
  }
})().catch(error => { console.error(error); process.exitCode = 1; });

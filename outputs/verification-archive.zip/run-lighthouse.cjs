const fs = require('node:fs');
const path = require('node:path');
const http = require('node:http');
const { pathToFileURL } = require('node:url');
const { createRequire } = require('node:module');
(async () => {
  const entry = require.resolve('./lighthouse/node_modules/lighthouse');
  const { default: lighthouse } = await import(pathToFileURL(entry));
  const localRequire = createRequire(entry);
  const chromeLauncher = await import(pathToFileURL(localRequire.resolve('chrome-launcher')));
  const root = path.resolve('outputs/site');
  const types = { '.html': 'text/html; charset=utf-8', '.css': 'text/css', '.js': 'text/javascript', '.json': 'application/json', '.svg': 'image/svg+xml', '.png': 'image/png' };
  const server = http.createServer((req,res) => {
    const file = path.resolve(root, '.' + (req.url === '/' ? '/index.html' : req.url.split('?')[0]));
    if(!file.startsWith(root + path.sep)) { res.writeHead(403).end(); return; }
    fs.readFile(file,(err,data) => {if(err){res.writeHead(404).end();return;}res.writeHead(200,{'Content-Type':types[path.extname(file)] || 'application/octet-stream'});res.end(data);});
  });
  await new Promise(resolve => server.listen(0,'127.0.0.1',resolve));
  let chrome;
  try {
    chrome = await chromeLauncher.launch({ userDataDir: path.resolve('work/lighthouse-profile'), chromePath: 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe', chromeFlags: ['--headless', '--no-sandbox'] });
    const result = await lighthouse(`http://127.0.0.1:${server.address().port}/`, { port: chrome.port, output: ['html','json'], logLevel: 'error', onlyCategories: ['performance','accessibility','best-practices','seo'] });
    fs.writeFileSync('outputs/lighthouse-report.html',result.report[0]);
    fs.writeFileSync('outputs/lighthouse-report.json',result.report[1]);
    console.log(JSON.stringify(Object.fromEntries(Object.entries(result.lhr.categories).map(([id,value])=>[id,value.score*100]))));
    console.log(JSON.stringify(Object.values(result.lhr.audits).filter(a=>a.score !== null && a.score < 1).map(a=>({id:a.id,title:a.title,score:a.score,details:a.details?.items})),null,2));
  } finally { try { if(chrome)await chrome.kill(); } finally { server.close(); } }
})().catch(error=>{console.error(error);process.exitCode=1;});

const fs = require('node:fs');
const path = require('node:path');
const JSZip = require(path.resolve(path.dirname(process.execPath), '../node_modules/jszip'));
(async () => {
  const zip = new JSZip();
  function add(name) {
    if (fs.statSync(name).isDirectory()) {
      for (const child of fs.readdirSync(name)) add(`${name}/${child}`);
    } else zip.file(name, fs.readFileSync(name));
  }
  for (const name of ['index.html','css','js','data','assets','scripts','.github','.nojekyll','.gitignore','README.md']) add(name);
  fs.writeFileSync('outputs/portfolio-github-pages.zip', await zip.generateAsync({ type:'nodebuffer', compression:'DEFLATE', compressionOptions:{ level:9 } }));
  console.log('Prepared source ZIP including the Pages workflow; no work or audit dependencies included.');
})();

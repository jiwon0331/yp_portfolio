const fs=require('fs'),path=require('path'),http=require('http'),assert=require('assert');
const {chromium}=require(path.resolve(path.dirname(process.execPath),'../node_modules/playwright'));
(async()=>{
const root=path.resolve('outputs/site');
const server=http.createServer((q,s)=>{const f=path.join(root,decodeURIComponent(q.url.split('?')[0]==='/'?'/index.html':q.url.split('?')[0])); if(!f.startsWith(root+path.sep)){s.writeHead(403).end();return;} fs.readFile(f,(e,b)=>{s.writeHead(e?404:200,{'Content-Type':({'.html':'text/html','.css':'text/css','.js':'text/javascript','.json':'application/json','.svg':'image/svg+xml','.png':'image/png'})[path.extname(f)]||'application/octet-stream'});s.end(e?'missing':b);});});
await new Promise(r=>server.listen(0,'127.0.0.1',r)); let browser;
try{ browser=await chromium.launch({executablePath:'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',headless:true});
for(const width of [375,430,768,1024,1440]) {
 const page=await browser.newPage({viewport:{width,height:900},reducedMotion:'reduce'}); const errors=[];page.on('pageerror',e=>errors.push(e.message));
 await page.goto('http://127.0.0.1:'+server.address().port);await page.locator('.project-case-button').first().waitFor();
 assert.equal(await page.locator('.project-card').count(),4);
 assert.equal(await page.locator('.skill-group').count(),5);
 assert.equal(await page.locator('.learning-card').count(),5);
 assert.equal(await page.locator('.learning-bring-list li').count(),4);
 assert.equal(await page.locator('.learning-card li').count(),15);
 assert(!(await page.locator('#skills').innerText()).includes('Google Workspace'));
 assert((await page.locator('#skills').innerText()).includes('TOEIC 940'));
 assert.equal(await page.locator('.skill-group').last().locator('.skill-level').count(),0);
 const cols=await page.locator('.learning-cards').evaluate(e=>getComputedStyle(e).gridTemplateColumns.split(' ').length);
 assert.equal(cols,width>=1120?3:width>=640?2:1);
 assert.deepEqual(await page.locator('[data-nav-link]').allTextContents(),['Experience','Projects','Skills','Learning','About','Contact']);
 assert.deepEqual(await page.locator('.section-heading > .eyebrow').allTextContents(),['01','02','03','04','05','06']);
 assert.equal(await page.locator('[data-resume-placeholder],.journey-number').count(),0);
 assert(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));
 for(const id of ['learning','contact']){if(width<960)await page.locator('.menu-toggle').click();await page.locator(`[data-nav-link][href="#${id}"]`).click();await page.waitForTimeout(100);assert.equal(await page.locator(`[data-nav-link][href="#${id}"]`).getAttribute('aria-current'),'location');}
 await page.locator('.project-case-button').first().click();assert(await page.locator('dialog').evaluate(d=>d.open));assert(await page.locator('dialog .title-ko').count()>3);await page.keyboard.press('Escape');assert(!(await page.locator('dialog').evaluate(d=>d.open)));
 assert.deepEqual(errors,[]);await page.goto('http://127.0.0.1:'+server.address().port);await page.locator('.project-card').first().waitFor();
 if([375,1440].includes(width)) { await page.locator('#skills').screenshot({path:`work/skills-${width}.png`}); await page.locator('#learning').screenshot({path:`work/learning-${width}.png`}); }
 console.log(width+': layout, navigation, numbering, modal passed');await page.close();
}
}finally{if(browser)await browser.close();server.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});

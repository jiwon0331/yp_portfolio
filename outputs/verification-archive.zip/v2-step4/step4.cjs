const fs=require('fs');const rd=p=>fs.readFileSync(p,'utf8'),wr=(p,s)=>fs.writeFileSync(p,s);
const label=(en,ko)=>`<span lang="en">${en}</span><span class="title-ko">${ko}</span>`;
const level=(ko,en)=>`<p class="skill-level"><span class="project-label">Level / 활용 수준</span>${ko} / <span lang="en">${en}</span></p>`;
const list=items=>`<ul class="skill-tools" role="list">${items.map(x=>`<li>${x}</li>`).join('')}</ul>`;
const evidence=body=>`<div class="skill-evidence"><p class="evidence-label">Evidence / 경험 근거</p>${body}</div>`;
const groups=[
['LANGUAGE','언어',`<div class="language-item"><h4>English / 영어</h4>${level('중상','Upper-intermediate')}${evidence('<p>TOEIC 940<br><time datetime="2025-07">2025.07</time> 취득</p>')}</div><div class="language-item"><h4>Spanish / 스페인어</h4>${level('하','Basic')}</div>`],
['CONTENT TOOLS','콘텐츠 제작',list(['Canva','MiriCanvas','CapCut'])+level('중','Intermediate')],
['OA','문서·데이터 활용',list(['Excel','PowerPoint'])+level('중','Intermediate')+evidence('<p>컴퓨터활용능력 1급<br><time datetime="2026-08">2026.08</time> 취득</p>')],
['AI-ASSISTED WORKFLOW','생성형 AI 활용',level('중','Intermediate')+evidence('<ul><li>생성형 AI를 활용한 요구사항 및 PRD 구조화</li><li>Codex / Claude Code 기반 간단한 웹페이지 및 웹앱 구현·수정</li><li>AI와의 반복적 디버깅 및 기능 개선</li><li>GitHub Pages를 활용한 결과물 배포</li></ul>')],
['RESEARCH &amp; DATA','조사·데이터',list(['SPSS','Survey Research / 설문조사','Interview / 인터뷰','Quantitative Analysis / 정량분석'])]
];
const skills=`      <section id="skills" class="section" aria-labelledby="skills-title">
        <div class="container">
          <div class="section-heading"><p class="eyebrow">03</p><h2 id="skills-title">${label('SKILLS','보유 역량')}</h2></div>
          <div class="skills-groups">${groups.map(([en,ko,body])=>`\n            <div class="skill-group"><h3>${label(en,ko)}</h3>${body}</div>`).join('')}
          </div>
        </div>
      </section>`;
const areas=[
['Project Operations &amp; Organizational Workflow','사업 운영 및 기관 업무 구조',['국제개발협력 사업의 행정적 운영','사업수행기관 내부의 업무 흐름','기관의 목표가 개별 사업에 연결되는 구조']],
['Documentation, Scheduling &amp; Reporting','일정·문서·보고',['사업 일정 관리','사업 문서 관리','기획서·보고서 등 사업 수행 과정의 문서 흐름']],
['Monitoring, Results &amp; Coordination','성과관리·협업 구조',['사업 성과 기록 및 관리','사업 모니터링의 실제 방식','기관·파트너·현지 관계자 등 이해관계자 간 협업 구조']],
['Project Development &amp; Research','신규사업 발굴·기획 지원',['신규 국제개발협력 사업 및 공모 모니터링','사업 관련 자료조사','신규사업 기획 및 제안 과정의 실무 지원']],
['Budget &amp; Administrative Process','예산·정산 및 사업 행정',['사업 예산이 편성·집행되는 기본 흐름','증빙 및 정산 과정','사업 운영과 행정 절차의 연결']]
];
const bring=[['Field &amp; Program Operations','현장·프로그램 운영'],['Communication &amp; Coordination','커뮤니케이션·협업'],['Documentation &amp; Organization','문서화·업무 구조화'],['Research &amp; Data','조사·데이터']];
const learning=`      <section id="learning" class="section" aria-labelledby="learning-title">
        <div class="container">
          <div class="section-heading"><p class="eyebrow">04</p><h2 id="learning-title">${label('INTEREST &amp; LEARNING','관심·학습 영역')}</h2></div>
          <div class="learning-column" aria-labelledby="learning-bring-title">
            <h3 id="learning-bring-title">${label('WHAT I BRING','현재 기여할 수 있는 역량')}</h3>
            <ul class="learning-bring-list" role="list">${bring.map(([en,ko])=>`<li>${label(en,ko)}</li>`).join('')}</ul>
          </div>
          <div class="learning-column" aria-labelledby="learning-interest-title">
            <h3 id="learning-interest-title">${label('WHAT I WANT TO LEARN','YP를 통해 확장하고 싶은 영역')}</h3>
            <p class="learning-note">아래는 YP 실무를 통해 배우고 싶은 영역입니다.</p>
            <div class="learning-cards">${areas.map(([en,ko,items])=>`\n              <article class="learning-card"><p class="evidence-label">학습 관심 영역</p><h4>${label(en,ko)}</h4><ul>${items.map(x=>`<li>${x}</li>`).join('')}</ul></article>`).join('')}
            </div>
          </div>
        </div>
      </section>`;
let h=rd('index.html');h=h.replace(/      <section id="skills"[\s\S]*?      <\/section>/,skills).replace(/      <section id="learning"[\s\S]*?      <\/section>/,learning);wr('index.html',h);
let css=rd('css/style.css');css=css.replace(/^\.learning-grid[^\n]*\n/gm,'').replace(/^\.learning-list[^\n]*\n/gm,'').replace(/^\.skills-groups[^\n]*\n/gm,'').replace(/^\.skill-group[^\n]*\n/gm,'');
css+='\n/* v2 tool evidence and clearly separated learning interests. */\n.skills-groups, .learning-cards { display: grid; gap: 20px; margin-top: 28px; }\n.skill-group, .learning-card { min-width: 0; padding: 24px; border: 1px solid var(--border); border-radius: var(--border-radius); }\n.skill-group h3 { color: var(--accent); font-size: var(--text-sm); line-height: 1.5; }\n.language-item { margin-top: 20px; }\n.language-item + .language-item { padding-top: 16px; border-top: 1px solid var(--border); }\n.language-item h4 { font-size: var(--text-base); }\n.skill-level { margin-top: 16px; font-size: var(--text-sm); }\n.skill-level .project-label { margin-bottom: 4px; }\n.skill-tools { display: flex; flex-wrap: wrap; gap: 8px 16px; padding: 0; margin-top: 16px; list-style: none; font-size: var(--text-sm); }\n.skill-evidence { margin-top: 16px; font-size: var(--text-sm); }\n.skill-evidence > p + p { margin-top: 6px; }\n.skill-evidence ul, .learning-card ul { display: grid; gap: 8px; margin-top: 12px; padding-left: 18px; font-size: var(--text-sm); }\n#learning .learning-column { margin-top: 32px; }\n.learning-bring-list { display: grid; gap: 20px; list-style: none; padding: 0; margin-top: 20px; font-size: var(--text-sm); }\n.learning-note { margin-top: 12px; color: var(--muted-text); font-size: var(--text-sm); }\n.learning-card h4 { margin-top: 12px; font-size: var(--text-base); line-height: 1.5; }\n';wr('css/style.css',css);
let responsive=rd('css/responsive.css').replace(/^  \.learning-grid[^\n]*\n/gm,'');responsive+='\n@media (min-width: 640px) { .skills-groups, .learning-cards, .learning-bring-list { grid-template-columns: repeat(2, minmax(0, 1fr)); } }\n@media (min-width: 1120px) { .skills-groups, .learning-cards { grid-template-columns: repeat(3, minmax(0, 1fr)); } .learning-bring-list { grid-template-columns: repeat(4, minmax(0, 1fr)); } }\n';wr('css/responsive.css',responsive);
let r=rd('README.md');r=r.replace('실제 연락처 및 사진은 이후 제공되는 콘텐츠로 추가합니다.','STEP 4에서 Skills를 언어·콘텐츠·OA·생성형 AI 활용·조사 데이터로 정리하고 제공된 수준 및 자격 근거를 반영했습니다. Learning은 현재 기여 역량 4개와 앞으로 배우고 싶은 영역 5개로 구분했습니다. 실제 연락처 및 사진은 이후 제공되는 콘텐츠로 추가합니다.');wr('README.md',r);
